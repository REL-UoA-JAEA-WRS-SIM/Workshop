/*
  \author Fumiaki Abe
*/
#include <cnoid/SimpleController>
#include <cnoid/SharedJoystick>
#include <cnoid/Body>
#include <cnoid/JointPath>
#include <boost/format.hpp>
#include <cnoid/EigenUtil>
#include "Interpolator.h"
#include <iostream>
#include <unistd.h>



using namespace std;
using namespace cnoid;
using boost::format;

class JacoArm2KinematicsController : public SimpleController
{
    Body* ioBody;
    Link* ioFINGER1;
    Link* ioFINGER2;
    Link* ioFINGER3;
    BodyPtr ikBody;
    Link* ikWrist;
    std::shared_ptr<cnoid::JointPath> baseToWrist;
    Link::ActuationMode mainActuationMode;
    VectorXd qref, qold, qref_old;
    Interpolator<VectorXd> wristInterpolator;
    Interpolator<VectorXd> jointInterpolator;
    int phase;
    double currentTime;
    double time;
    double timeStep;
    double dq_hand;
    int controlModeflg = 0;

    struct JointInfo {
        Link* joint;
        double qref;
        double qold;
        double kp;
        double kd;
    };

    vector<JointInfo> jointInfos;

    struct JointSpec {
        string name;
        double kp_torque;
        double kd_torque;
        double kp_velocity;
    };

    enum {
        ARM2_SHOULDER,
        ARM2_ARM,
        ARM2_FOREARM,
        ARM2_WRIST1,
        ARM2_WRIST2,
        ARM2_HAND,
        ARM2_FINGER1,
        ARM2_FINGER1_TIP,
        ARM2_FINGER2,
        ARM2_FINGER2_TIP,
        ARM2_FINGER3,
        ARM2_FINGER3_TIP,
        NUM_JOINTS
    };

    SharedJoystickPtr joystick;
    int targetMode;

public:
    Matrix3d RotateX(double radian){
        Matrix3d rotX = MatrixXd::Zero(3,3);
        rotX(0,0) = 1;
        rotX(1,1) = cos(radian);
        rotX(1,2) = -sin(radian);
        rotX(2,1) = sin(radian);
        rotX(2,2) = cos(radian);
        return rotX; 
    }

    Matrix3d RotateY(double radian){
        Matrix3d rotY = MatrixXd::Zero(3,3);
        rotY(0,0) = cos(radian);
        rotY(0,2) = sin(radian);
        rotY(1,1) = 1;
        rotY(2,0) = -sin(radian);
        rotY(2,2) = cos(radian);
        return rotY; 
    }

    Matrix3d RotateZ(double radian){
        Matrix3d rotZ = MatrixXd::Zero(3,3);
        rotZ(0,0) = cos(radian);
        rotZ(0,1) = -sin(radian);
        rotZ(1,0) = sin(radian);
        rotZ(1,1) = cos(radian);
        rotZ(2,2) = 1;
        return rotZ; 
    }

    Vector3 toRadianVector3(double x, double y, double z)
    {
        return Vector3(radian(x), radian(y), radian(z));
    }


     virtual bool initialize(SimpleControllerIO* io) override
     {
         currentTime = io->currentTime();
         ioBody = io->body();
         timeStep = io->timeStep();
         ikBody = ioBody->clone();
         ikWrist = ikBody->link("ARM2_HAND");
         ioFINGER1 = ioBody->link("FINGER1");
         ioFINGER2 = ioBody->link("FINGER2");
         ioFINGER3 = ioBody->link("FINGER3");

         Link* base = ikBody->rootLink();
         baseToWrist = getCustomJointPath(ikBody, base, ikWrist);
         base->p().setZero();
         base->R().setIdentity();
         
         mainActuationMode = Link::JOINT_TORQUE;
         string prefix;
         for(auto& option : io->options()){
             if(option == "velocity"){
                 mainActuationMode = Link::JOINT_VELOCITY;
                 io->os() << "velocity mode" << endl;
             } else if(option == "position"){
                 mainActuationMode = Link::JOINT_ANGLE;
                 io->os() << "position mode" << endl;
             } else if(option == "torque"){
                 mainActuationMode = Link::JOINT_TORQUE;
                 io->os() << "torque mode" << endl;
             } else {
                 prefix = option;
                 io->os() << "prefix: " << prefix << endl;
             }
         }

        jointInfos.clear();
        const double P_GAIN_VELOCITY = 0.5;
        vector<JointSpec> specs(NUM_JOINTS);

        if(io->timeStep() < 0.02){
        //                                      P      D        P (vel) 
          specs[ARM2_SHOULDER    ] = { "ARM2_SHOULDER",  1000.0, 100,  P_GAIN_VELOCITY };
          specs[ARM2_ARM         ] = { "ARM2_ARM",       1000.0, 100,  P_GAIN_VELOCITY };
          specs[ARM2_FOREARM     ] = { "ARM2_FOREARM",   600.0,  60,   P_GAIN_VELOCITY };
          specs[ARM2_WRIST1      ] = { "ARM2_WRIST1",    300.0,   30,  P_GAIN_VELOCITY };
          specs[ARM2_WRIST2      ] = { "ARM2_WRIST2",    300.0,   30,  P_GAIN_VELOCITY };
          specs[ARM2_HAND        ] = { "ARM2_HAND",      250.0,   25,  P_GAIN_VELOCITY };
          specs[ARM2_FINGER1     ] = { "ARM2_FINGER1",     30,     3,  P_GAIN_VELOCITY };
          specs[ARM2_FINGER1_TIP ] = { "ARM2_FINGER1_TIP", 20,     2,  P_GAIN_VELOCITY };
          specs[ARM2_FINGER2     ] = { "ARM2_FINGER2",     30,     3,  P_GAIN_VELOCITY };
          specs[ARM2_FINGER2_TIP ] = { "ARM2_FINGER2_TIP", 20,     2,  P_GAIN_VELOCITY };
          specs[ARM2_FINGER3     ] = { "ARM2_FINGER3",     30,     3,  P_GAIN_VELOCITY };
          specs[ARM2_FINGER3_TIP ] = { "ARM2_FINGER3_TIP", 20,     2,  P_GAIN_VELOCITY };
        } else {
        //                                     P      D      P (vel)
          specs[ARM2_SHOULDER    ] = { "ARM2_SHOULDER",   400.0, 30.0,  P_GAIN_VELOCITY };
          specs[ARM2_ARM         ] = { "ARM2_ARM",        400.0, 30.0,  P_GAIN_VELOCITY };
          specs[ARM2_FOREARM     ] = { "ARM2_FOREARM",    150.0, 15.0,  P_GAIN_VELOCITY };
          specs[ARM2_WRIST1      ] = { "ARM2_WRIST1",      60.0,  5.0,  P_GAIN_VELOCITY };
          specs[ARM2_WRIST2      ] = { "ARM2_WRIST2",      60.0,  5.0,  P_GAIN_VELOCITY };
          specs[ARM2_HAND        ] = { "ARM2_HAND",        60.0,  5.0,  P_GAIN_VELOCITY };
          specs[ARM2_FINGER1     ] = { "ARM2_FINGER1",     5.0,  0.5,  P_GAIN_VELOCITY };
          specs[ARM2_FINGER1_TIP ] = { "ARM2_FINGER1_TIP", 3.0,  0.3,  P_GAIN_VELOCITY };
          specs[ARM2_FINGER2     ] = { "ARM2_FINGER2",     5.0,  0.5,  P_GAIN_VELOCITY };
          specs[ARM2_FINGER2_TIP ] = { "ARM2_FINGER2_TIP", 3.0,  0.3,  P_GAIN_VELOCITY };
          specs[ARM2_FINGER3     ] = { "ARM2_FINGER3",     5.0,  0.5,  P_GAIN_VELOCITY };
          specs[ARM2_FINGER3_TIP ] = { "ARM2_FINGER3_TIP", 3.0,  0.3,  P_GAIN_VELOCITY };
        }
    
        if(!initializeJoints(io, specs, prefix)){
            return false;
        }

        joystick = io->getOrCreateSharedObject<SharedJoystick>("joystick");
        targetMode = joystick->addMode();
        

        // input  present joint angle data.
        qold.resize(ioBody->numJoints());
        for(int i=0; i < ioBody->numJoints(); ++i){
            qold[i] = ioBody->joint(i)->q();
        }

        baseToWrist->calcForwardKinematics();
        qref = qold;
        qref_old = qold;

        phase = 0;
        time = 0.0;
        dq_hand = 0.0;
        return true;
     }



    bool initializeJoints(SimpleControllerIO* io, vector<JointSpec>& specs, const string& prefix)
    {

        for(auto& spec : specs){
        string name = prefix + spec.name;
        auto joint = ioBody->link(name);
        io->os() << "print test : " << name << endl;
        if(!joint){
            io->os() << format("%1% of %2% is not found") % name % ioBody->name() << endl;
            return false;
        }
        joint->setActuationMode(mainActuationMode);
        io->enableIO(joint);

        JointInfo info;
        info.joint = joint;
        info.qref = info.qold = joint->q();


        if(mainActuationMode == Link::JOINT_VELOCITY){
            info.kp = spec.kp_velocity;
        } else if(mainActuationMode == Link::JOINT_TORQUE){
            info.kp = spec.kp_torque;
            info.kd = spec.kd_torque;
            }    
            jointInfos.push_back(info);
        }   
        return true;
    }

    virtual bool control() override
    {    
        currentTime += timeStep;
        joystick->updateState(targetMode);
        bool isActive = true;
        controlModeflg = updateControlflg();
//        if(controlModeflg == 0){
            //updateTargetJointAngles();
	    updateTargetJointAnglesBYInverseKinematicks();
        // }
        // else {
        //     sequence();
            
        // }
        
 
        switch(mainActuationMode){
        case Link::JOINT_TORQUE:
            controlJointsWithTorque();
            break;
        case Link::JOINT_VELOCITY:
            controlJointsWithVelocity();
            break;
        case Link::JOINT_ANGLE:
            controlJointsWithPosition();
            break;
        default:
            break;
        }
 
        time += timeStep;
        //cout << "roll " <<  << endl;
        return isActive;
    }
    void sequence(){
        static int seqNum = 0;
        static bool flag = false;
        static bool isActive =false;
        static bool buttonflag = false;
        static int count = 0;
        if(joystick->getButtonState(Joystick::L_BUTTON) && buttonflag == false){
                seqNum = 1;
                flag = true;
                buttonflag = true;
        }
        if(joystick->getButtonState(Joystick::R_BUTTON)){
            seqNum = 2;
        }
       
        //void perform(seqNum);
        if(flag){
            cout << "in the perform" << endl;
            flag = perform(seqNum);
            isActive =true;
        }
        
        if(isActive && !flag && ++count > 2 ){
            VectorXd p(6);
            p = wristInterpolator.interpolate(currentTime);
        
            if(baseToWrist->calcInverseKinematics(
                Vector3(p.head<3>()), ikWrist->calcRfromAttitude(rotFromRpy(Vector3(p.tail<3>()))))){
                for(int i=0; i < baseToWrist->numJoints(); ++i){
                    Link* joint = baseToWrist->joint(i);
                    qref[joint->jointId()] = joint->q();
                }
            }
            if(currentTime > wristInterpolator.domainUpper()){
                cout << "domainUpper" << endl;
                isActive = false;
                buttonflag = false;
                count = 0;
        }

//        VectorXd position(3);
  //      position = ikWrist->p();
    //    cout << "p(x) : " << position(0) << " p(y) : " << position(1) << " p(z) : "<< position(2) << endl;
    } else{}
    
    
    }

    bool perform(int seqNum){
       //for(int i=0; i<1000; i++)
        //sleep(1);
        if (seqNum == 1){
            cout << "in perform func " <<endl<<endl;
            //baseToWrist->calcForwardKinematics();


            ikBody = ioBody->clone();
            ikWrist = ikBody->link("ARM2_HAND");
            Link* base = ikBody->rootLink();
            baseToWrist = getCustomJointPath(ikBody, base, ikWrist);

            //baseToWrist->calcInverseKinematics(ikWrist->p(),ikWrist->R());
            baseToWrist->calcForwardKinematics();

            
            VectorXd position(3);
            position = ikWrist->p();
            cout << "p(x) : " << position(0) << " p(y) : " << position(1) << " p(z) : "<< position(2) << endl;

            VectorXd p0(6);
            p0.head<3>() = ikWrist->p();
            p0.tail<3>() = rpyFromRot(ikWrist->attitude());
            VectorXd p1(6); 
            p1.head<3>() = Vector3(0.0, 0.3, 0.3);
            p1.tail<3>() = toRadianVector3(-171.0, -10, -90.0);
            //p1.tail<3>() = rpyFromRot(ikWrist->attitude());
            wristInterpolator.clear();

            wristInterpolator.appendSample(currentTime + 2.0, p0);
            wristInterpolator.appendSample(currentTime + 4.0, p1);
            p1.z() = 0.45;
            wristInterpolator.appendSample(currentTime + 7.0, p1);
            wristInterpolator.update();
            cout << "last perform function " << endl;
            sleep(3);
            //time = 0.0;
       }        
        return false;
    }

    void updateTargetJointAngles()
    {
        static const double K = 0.8;
        // 左アナログスティック左右
        setTargetJointAngle(ARM2_SHOULDER, Joystick::L_STICK_H_AXIS, -K);
        // 左アナログスティッ上下
        setTargetJointAngle(ARM2_ARM,      Joystick::L_STICK_V_AXIS, -K);
        // 右アナログスティック左右
        setTargetJointAngle(ARM2_FOREARM,  Joystick::R_STICK_V_AXIS,  K);
        // 右アナログスティック上下 
        setTargetJointAngle(ARM2_WRIST1,   Joystick::R_STICK_H_AXIS, -K);
         // ○ボタン, □ボタン
        setTargetJointAngle(ARM2_WRIST2, Joystick::B_BUTTON, Joystick::X_BUTTON, K);
         // L1, R1ボタン
        setTargetJointAngle(ARM2_HAND,   Joystick::R_BUTTON, Joystick::L_BUTTON, 1.2 * K);

        setTargetJointAngle(ARM2_FINGER1, Joystick::A_BUTTON, Joystick::Y_BUTTON, 0.4);
        setTargetJointAngle(ARM2_FINGER2, Joystick::A_BUTTON, Joystick::Y_BUTTON, 0.4);
        setTargetJointAngle(ARM2_FINGER3, Joystick::A_BUTTON, Joystick::Y_BUTTON, 0.4);

        double dq_finger = 0.0;
        double lt = joystick->getPosition(targetMode, Joystick::L_TRIGGER_AXIS);
        if(lt > 0.1){
            dq_finger -= timeStep * 0.4 * lt;
        }
        double rt = joystick->getPosition(targetMode, Joystick::R_TRIGGER_AXIS);
        if(rt > 0.1){
            dq_finger += timeStep * 0.4 * rt;
        }

        for(int i = ARM2_FINGER1; i <= ARM2_FINGER3; ++i){
            qref[i] += dq_finger;
        }
    }

    void setTargetJointAngle(int jointID, Joystick::AxisID stickID, double k)
    {
        qref[jointID] += timeStep * k * joystick->getPosition(targetMode, stickID, 0.1);
    }
    void setTargetJointAngle(int jointID, Joystick::ButtonID button1, Joystick::ButtonID button2, double k)
    {
        double dq = 0.0;
        if(joystick->getButtonState(targetMode, button1)){
            dq -= timeStep * k;
        }
        if(joystick->getButtonState(targetMode, button2)){
            dq += timeStep * k;
        }
        qref[jointID] += dq;
    }
    
        
double deg2rad(double degree)
{
    return degree * M_PI / 180.0f;
}

double rad2deg(double radian)
{
    return radian * 180.0f/ M_PI;
}

void updateTargetJointAnglesBYInverseKinematicks()
{ 
        // 手首座標
        baseToWrist->calcForwardKinematics();
        Vector3d p =  ikWrist->p();
        Matrix3d R =  ikWrist->R();
        p(0) -= (float)joystick->getPosition(targetMode, Joystick::L_STICK_V_AXIS, 0.1) /2000;
        p(1) -= (float)joystick->getPosition(targetMode, Joystick::L_STICK_H_AXIS, 0.1) /2000;  
        p(2) -= (float)joystick->getPosition(targetMode, Joystick::R_STICK_V_AXIS, 0.1) /2000;  

        
        //if(m_button_L.data[0]){
        if(joystick->getButtonState(targetMode, Joystick::L_BUTTON)){
            R *= RotateX(deg2rad(-0.2));
        }
        if(joystick->getButtonState(targetMode, Joystick::R_BUTTON)){
            R *= RotateX(deg2rad(0.2));
        }
        // 手首の操作
        if(joystick->getButtonState(targetMode, Joystick::Y_BUTTON)){
            R *= RotateZ(deg2rad(0.2));
        }
        if(joystick->getButtonState(targetMode, Joystick::A_BUTTON)){
            R *= RotateZ(deg2rad(-0.2));
        }
        if(joystick->getButtonState(targetMode, Joystick::X_BUTTON)){
            R *= RotateY(deg2rad(0.2));
        }
        if(joystick->getButtonState(targetMode, Joystick::B_BUTTON)){
            R *= RotateY(deg2rad(-0.2));
        }
        baseToWrist->calcInverseKinematics(p, R);
        
        //p1.tail<3>() = rpyFromRot(ikWrist2->attitude());
        Vector3d rpy = rpyFromRot(ikWrist->attitude());
        //rpy = ikWrist2->R();
        //cout << "x : " << p(0) << " y : " << p(1) << " z : " << p(2) << endl;
        //cout << "roll : " << rad2deg(rpy(0)) << " pitch : " << rad2deg(rpy(1)) << " yaw : " << rad2deg(rpy(2)) << endl;

         for(int i = 0; i <6; i++ )
         {
            Link* joint = baseToWrist->joint(i);             
	        jointInfos[i].qref = joint->q();
		
         }
        double dq_fingerL = 0.0;
        double ltL = joystick->getPosition(targetMode, Joystick::L_TRIGGER_AXIS);
            dq_fingerL -= ltL;
        double rtL = joystick->getPosition(targetMode, Joystick::R_TRIGGER_AXIS);
            dq_fingerL += rtL;    
        for(int i = ARM2_FINGER1; i <= ARM2_FINGER3; ++i){
            jointInfos[i].qref += 0.005*dq_fingerL;
        }
}

int updateControlflg()
{
    static int flag = controlModeflg;
    static int count = 0;
    static bool cflag = false;
     
    if(joystick->getButtonState(targetMode, Joystick::L_STICK_BUTTON)){
        cflag = true;
    }
    if(cflag){
        // increment the controlModeflg when the count become more than 200 
        if(++count > 200 ){
            cflag = false;
            count = 0;
            ++flag;
            if (flag == 2){flag = 0;}
        }
    }
    return flag; 
}

void controlJointsWithTorque()
{
    for(int i=0; i < ioBody->numJoints(); ++i){
        double q = ioBody->joint(i)->q();
        double dq = (q - qold[i]) / timeStep;
        double dq_ref = (qref[i] - qref_old[i]) / timeStep; //これ注意！！
        ioBody->joint(i)->u() = (qref[i] - q) * jointInfos[i].kp + (0.0 - dq) * jointInfos[i].kd;
        qold[i] = q;
        //cout << "joint Torque : " << ioBody->joint(i)->u() << endl;
        }
        qref_old = qref;
}


void controlJointsWithVelocity()
{
    for(int i=0; i < ioBody->numJoints(); ++i){
        double q = ioBody->joint(i)->q();
        double dq = (q - qold[i]) / timeStep;
        ioBody->joint(i)->dq_target() = jointInfos[i].kp * (qref[i] - q) /timeStep;
    }
}


void controlJointsWithPosition()
{
    for(auto& info : jointInfos){
        info.joint->q_target() = info.qref;
    }
}

};

CNOID_IMPLEMENT_SIMPLE_CONTROLLER_FACTORY(JacoArm2KinematicsController)
