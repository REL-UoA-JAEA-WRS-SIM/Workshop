import WRSUtil
WRSUtil.loadProject(
    "SingleSceneView", "T3", "AISTSimulator", "AizuSpiderDS",
    enableVisionSimulation = True, remoteType = "RTM")
