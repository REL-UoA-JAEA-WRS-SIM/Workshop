import WRSUtil
WRSUtil.loadProject(
    "SingleSceneView", "T4", "AGXSimulator", "AizuSpiderDA",
    enableVisionSimulation = True, remoteType = "RTM")