import WRSUtil
WRSUtil.loadProject(
    "SingleSceneView", "T2", "AGXSimulator", "AizuSpiderDA",
    enableVisionSimulation = True, remoteType = "RTM")