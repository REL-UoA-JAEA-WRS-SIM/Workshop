import WRSUtil
WRSUtil.loadProject(
    "SingleSceneView", "T6", "AGXSimulator", "AizuSpiderDA",
    enableVisionSimulation = True, remoteType = "RTM")