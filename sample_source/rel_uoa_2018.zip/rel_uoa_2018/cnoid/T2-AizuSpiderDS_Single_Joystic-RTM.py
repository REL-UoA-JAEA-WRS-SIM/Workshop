import WRSUtil
WRSUtil.loadProject(
    "SingleSceneView", "T2", "AISTSimulator", "AizuSpiderDS_Single_Joystic",
    enableVisionSimulation = True, remoteType = "RTM")
