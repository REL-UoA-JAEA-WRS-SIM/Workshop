import WRSUtil
WRSUtil.loadProject(
    "SingleSceneView", "T3", "AGXSimulator", "AizuSpiderDA",
    enableVisionSimulation = True, remoteType = "RTM")