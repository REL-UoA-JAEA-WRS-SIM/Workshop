import WRSUtil
WRSUtil.loadProject(
    "SingleSceneView", "T2", "AGXSimulator", "RELUoARobot_AGX",
    enableVisionSimulation = True, remoteType = "RTM")