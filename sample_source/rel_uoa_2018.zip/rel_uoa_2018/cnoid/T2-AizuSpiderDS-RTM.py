import WRSUtil
WRSUtil.loadProject(
    "SingleSceneView", "T2", "AISTSimulator", "AizuSpiderDS",
    enableVisionSimulation = True, remoteType = "RTM")
