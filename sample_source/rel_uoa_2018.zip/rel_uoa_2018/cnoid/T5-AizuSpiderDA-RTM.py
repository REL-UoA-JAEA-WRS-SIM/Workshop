import WRSUtil
WRSUtil.loadProject(
    "SingleSceneView", "T5", "AGXSimulator", "AizuSpiderDA",
    enableVisionSimulation = True, remoteType = "RTM")