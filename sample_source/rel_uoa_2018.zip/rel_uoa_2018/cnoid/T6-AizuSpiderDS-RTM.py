import WRSUtil
WRSUtil.loadProject(
    "SingleSceneView", "T6", "AISTSimulator", "AizuSpiderDS",
    enableVisionSimulation = True, remoteType = "RTM")
