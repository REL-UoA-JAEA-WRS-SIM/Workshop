import WRSUtil
WRSUtil.loadProject(
    "SingleSceneView", "T5", "AISTSimulator", "AizuSpiderDS",
    enableVisionSimulation = True, remoteType = "RTM")
