import WRSUtil
WRSUtil.loadProject(
    "SingleSceneView", "T4", "AISTSimulator", "AizuSpiderDS",
    enableVisionSimulation = True, remoteType = "RTM")
