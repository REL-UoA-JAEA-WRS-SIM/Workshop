#include <cnoid/SimpleController>
#include <cnoid/SharedJoystick>
#include <cnoid/Body>
#include <cnoid/JointPath>
#include <boost/format.hpp>
#include <cnoid/EigenUtil>
#include <iostream>
#include <unistd.h>


using namespace std;
using namespace cnoid;
using boost::format;

class EndscopeController_synchro_mode : public SimpleController
{
    Body* ioBody;
    Link* ioFINGER1;
    Link* ioFINGER2;
    Link* ioFINGER3;
    Link::ActuationMode mainActuationMode;
    VectorXd qref, qold, qref_old;
    double time;
    double timeStep;
    int controlModeflg = 0;

    struct JointInfo {
        Link* joint;
        double qref;
        double qold;
        double kp;
        double kd;
    };

    vector<JointInfo> jointInfos;

    struct JointSpec {
        string name;
        double kp_torque;
        double kd_torque;
        double kp_velocity;
    };

    enum {
        A,
        B,
        C,
        D,
        E,
        NUM_JOINTS
    };

    SharedJoystickPtr joystick;
    int targetMode;

public:


    Vector3 toRadianVector3(double x, double y, double z)
    {
        return Vector3(radian(x), radian(y), radian(z));
    }


     virtual bool initialize(SimpleControllerIO* io) override
     {
         ioBody = io->body();
         timeStep = io->timeStep();

         
         mainActuationMode = Link::JOINT_VELOCITY;
         string prefix;
         for(auto& option : io->options()){
             if(option == "velocity"){
                 mainActuationMode = Link::JOINT_VELOCITY;
                 io->os() << "velocity mode" << endl;
             } else if(option == "position"){
                 mainActuationMode = Link::JOINT_ANGLE;
                 io->os() << "position mode" << endl;
             } else if(option == "torque"){
                 mainActuationMode = Link::JOINT_TORQUE;
                 io->os() << "torque mode" << endl;
             } else {
                 prefix = option;
                 io->os() << "prefix: " << prefix << endl;
             }
         }

        jointInfos.clear();
        const double P_GAIN_VELOCITY = 0.5;
        vector<JointSpec> specs(NUM_JOINTS);

        if(io->timeStep() < 0.02){
        //                         P      D        P (vel) 
          specs[ A ] = { "A",    0.6,     0.07,  P_GAIN_VELOCITY };
          specs[ B ] = { "B",    3.8,     0.08,  P_GAIN_VELOCITY };
          specs[ C ] = { "C",    2.4,     0.03,  P_GAIN_VELOCITY };
          specs[ D ] = { "D",    2.2,     0.03,  P_GAIN_VELOCITY };
          specs[ E ] = { "E",    2.0,    0.005,  P_GAIN_VELOCITY };
          } else {
        //                        P      D      P (vel)
          specs[ A ] = { "A",    0.01,   1,  P_GAIN_VELOCITY };
          specs[ B ] = { "B",    0.01,   1,  P_GAIN_VELOCITY };
          specs[ C ] = { "C",    0.01,   1,  P_GAIN_VELOCITY };
          specs[ D ] = { "D",    0.01,   1,  P_GAIN_VELOCITY };
          specs[ E ] = { "E",    0.01,   1,  P_GAIN_VELOCITY };
        }
    
        if(!initializeJoints(io, specs, prefix)){
            return false;
        }
        joystick = io->getOrCreateSharedObject<SharedJoystick>("joystick");
        targetMode = joystick->addMode();
        
        // input  present joint angle data.
        qold.resize(ioBody->numJoints());
        for(int i=0; i < ioBody->numJoints(); ++i){
            qold[i] = ioBody->joint(i)->q();
        }

        qref = qold;
        qref_old = qold;

        time = 0.0;
        return true;
     }



    bool initializeJoints(SimpleControllerIO* io, vector<JointSpec>& specs, const string& prefix)
    {
        for(auto& spec : specs){
        string name = prefix + spec.name;
        auto joint = ioBody->link(name);
        if(!joint){
            io->os() << format("%1% of %2% is not found") % name % ioBody->name() << endl;
            return false;
        }
        joint->setActuationMode(mainActuationMode);
        io->enableIO(joint);

        JointInfo info;
        info.joint = joint;
        info.qref = info.qold = joint->q();

        if(mainActuationMode == Link::JOINT_VELOCITY){
            info.kp = spec.kp_velocity;
        } else if(mainActuationMode == Link::JOINT_TORQUE){
            info.kp = spec.kp_torque;
            info.kd = spec.kd_torque;
            }    
            jointInfos.push_back(info);
        }   
        return true;
    }

    virtual bool control() override
    {  
        joystick->updateState(targetMode);
        bool isActive = true;
            updateTargetJointAngles();
    
        switch(mainActuationMode){
        case Link::JOINT_TORQUE:
            controlJointsWithTorque();
            break;
        case Link::JOINT_VELOCITY:
            controlJointsWithVelocity();
            break;
        case Link::JOINT_ANGLE:
            controlJointsWithPosition();
            break;
        default:
            break;
        }

        time += timeStep;
        return isActive;
    }



    void updateTargetJointAngles()
    {
        static const double K = 0.2;
        // 左アナログスティック左右
        setTargetJointAngle(A, Joystick::L_STICK_H_AXIS, K);
        // 右アナログスティッ上下
        setTargetJointAngle_syncro(Joystick::R_STICK_V_AXIS, -K);
        
    }

    void setTargetJointAngle(int jointID, Joystick::AxisID stickID, double k)
    {
        qref[jointID] += timeStep * k * joystick->getPosition(targetMode, stickID, 0.1);
    }
    void setTargetJointAngle(int jointID, Joystick::ButtonID button1, Joystick::ButtonID button2, double k)
    {
        double dq = 0.0;
        if(joystick->getButtonState(targetMode, button1)){
            dq -= timeStep * k;
        }
        if(joystick->getButtonState(targetMode, button2)){
            dq += timeStep * k;
        }
        qref[jointID] += dq;
    }
    void setTargetJointAngle(int jointID, Joystick::ButtonID button1, Joystick::AxisID stickID, double k)
    {
        double dq = 0.0;
        if(joystick->getButtonState(targetMode, button1)){
            qref[jointID] -= timeStep * k;
        }
        double lt = joystick->getPosition(targetMode, stickID, k);
        if(lt > 0.1){
            qref[jointID] += timeStep* k * lt;
        }
    }

    void setTargetJointAngle_syncro(Joystick::AxisID stickID, double k){
        for(int i=1; i<5; i++){
            qref[i] += timeStep * k * joystick->getPosition(targetMode, stickID, 0.1);
        }
    }


    void controlJointsWithTorque()
    {
        for(int i=0; i < ioBody->numJoints(); ++i){
            double q = ioBody->joint(i)->q();
            double dq = (q - qold[i]) / timeStep;
            double dq_ref = (qref[i] - qref_old[i]) / timeStep; //これ注意！！
            ioBody->joint(i)->u() = (qref[i] - q) * jointInfos[i].kp + (0.0 - dq) * jointInfos[i].kd;
            qold[i] = q;
        }
        qref_old = qref;
    }
    
    
    void controlJointsWithVelocity()
    {
        for(int i=0; i < ioBody->numJoints(); ++i){
            double q = ioBody->joint(i)->q();
            double dq = (q - qold[i]) / timeStep;
            ioBody->joint(i)->dq_target() = jointInfos[i].kp * (qref[i] - q) /timeStep;
        }
    }
    
    
    void controlJointsWithPosition()
    {
        for(auto& info : jointInfos){
            info.joint->q_target() = info.qref;
        }
    } 
};

CNOID_IMPLEMENT_SIMPLE_CONTROLLER_FACTORY(EndscopeController_synchro_mode)
