/*
    Written by Fumiaki Abe
    2020/01/27
*/

#include <cnoid/SimpleController>
#include <cnoid/SharedJoystick>
#include <cnoid/Joystick>
#include <iostream>

using namespace cnoid;
using namespace std;


class ExtendableArmController : public cnoid::SimpleController
{
    vector<Link*> Links;
    Joystick joystick;
    double dt;

    struct JointInfo {
        Link* joint;
        double qref;
        double qold;
        double kp;
        double kd;
    };
    vector<JointInfo> jointInfos;
    Link::ActuationMode mainActuationMode;


public:

    virtual bool initialize(SimpleControllerIO* io) override
    {
        dt = io->timeStep();
        Links.push_back(io->body()->link("CAM_ARM2"));
        Links.push_back(io->body()->link("CAM_ARM3"));
        Links.push_back(io->body()->link("CAM_ARM4"));

        jointInfos.clear();

        for(auto& link: Links){
            link->setActuationMode(Link::JOINT_DISPLACEMENT);
            io->enableOutput(link);
            io->enableInput(link, JOINT_DISPLACEMENT | JOINT_VELOCITY);
            JointInfo info;
            info.joint = link;
            info.qref = info.qold = link->q();
        
            if(mainActuationMode == Link::JOINT_VELOCITY){
                info.kp = 0.5;
            } else if(mainActuationMode == Link::JOINT_TORQUE){
                info.kp = 800;
                info.kd = 20;
            }
        
            jointInfos.push_back(info);
        }

        if(!Links[0]){
            io->os() << "Spring-damper joint <UPPER2> cannot be detected."
                     << std::endl;     
            return false;
        }
        return true;
    }

    virtual bool control() override
    {
        const double KP = 1800.0;
        const double KD = 4.0;

        joystick.readCurrentState();

        double pos;
        pos = joystick.getPosition(0);
        if(fabs(pos) < 0.2){
                pos = 0.0;
        }

        for(auto& info : jointInfos){
            auto joint = info.joint;
            joint->q_target() += 0.0001*pos;
            if(joint->q() > 0.8){
                joint->q_target() = 0.8;    
            }
            if(joint->q() < 0.0){
                joint->q_target() = 0.0;    
            }
        }   
        return true;
    }
};

CNOID_IMPLEMENT_SIMPLE_CONTROLLER_FACTORY(ExtendableArmController)