/*
    Written by Fumiaki Abe
    2020/01/27
*/

#include <cnoid/SimpleController>
#include <cnoid/SharedJoystick>
#include <cnoid/Joystick>
#include <iostream>

using namespace cnoid;
using namespace std;


class ExtendableArmCameraController : public cnoid::SimpleController
{
    vector<Link*> PrismaticLinks;
    vector<Link*> RevoluteLinks;
    Joystick joystick;
    double dt;

    struct JointInfo {
        Link* joint;
        double qref;
        double qold;
        double kp;
        double kd;
    };
    vector<JointInfo> PrismaticjointInfos;
    vector<JointInfo> RevolutejointInfos;
    Link::ActuationMode mainActuationMode;


public:

    virtual bool initialize(SimpleControllerIO* io) override
    {
        dt = io->timeStep();
        PrismaticLinks.push_back(io->body()->link("CAM_ARM2")); // revolute joint
        PrismaticLinks.push_back(io->body()->link("CAM_ARM3")); // revolute joint
        PrismaticLinks.push_back(io->body()->link("CAM_ARM4")); // revolute joint
        RevoluteLinks.push_back(io->body()->link("CAM_ARM5")); // prismatic joint
        RevoluteLinks.push_back(io->body()->link("CAM_ARM6")); // prismatic joint
        RevoluteLinks.push_back(io->body()->link("CAM_ARM7")); // prismatic Joint

        PrismaticjointInfos.clear();
        RevolutejointInfos.clear();

        for(auto& link: PrismaticLinks){
            link->setActuationMode(Link::JOINT_DISPLACEMENT);
            //io->enableIO(link);
            io->enableOutput(link);
            io->enableInput(link, JOINT_DISPLACEMENT | JOINT_VELOCITY);
            JointInfo info;
            info.joint = link;
            info.qref = info.qold = link->q();
        
            if(mainActuationMode == Link::JOINT_VELOCITY){
                info.kp = 0.5;
            } else if(mainActuationMode == Link::JOINT_TORQUE){
                info.kp = 800;
                info.kd = 20;
            }
            PrismaticjointInfos.push_back(info);
        }
   
        for(auto& link: RevoluteLinks){
            link->setActuationMode(Link::JOINT_VELOCITY);
            io->enableIO(link);
            JointInfo info;
            info.joint = link;
            info.qref = info.qold = link->q();
        
            if(mainActuationMode == Link::JOINT_VELOCITY){
                info.kp = 0.5;
            } else if(mainActuationMode == Link::JOINT_TORQUE){
                info.kp = 800;
                info.kd = 20;
            } else {
                info.kp = 0.1;
            }
            RevolutejointInfos.push_back(info);
        }

        return true;
    }

    virtual bool control() override
    {
        const double KP = 1800.0;
        const double KD = 4.0;

        joystick.readCurrentState();

        double pos;
        pos = joystick.getPosition(0);
        if(fabs(pos) < 0.2){
                pos = 0.0;
        }
                if(joystick.getButtonState(Joystick::L_BUTTON)){
                    RevolutejointInfos[0].qref += 0.0005;
                }
                if(joystick.getButtonState(Joystick::R_BUTTON)){
                    RevolutejointInfos[0].qref -= 0.0005;
                }
                if(joystick.getButtonState(Joystick::X_BUTTON)){
                    RevolutejointInfos[1].qref += 0.0005;
                }
                if(joystick.getButtonState(Joystick::B_BUTTON)){
                    RevolutejointInfos[1].qref -= 0.0005;
                }

                if(joystick.getButtonState(Joystick::Y_BUTTON)){
                    RevolutejointInfos[2].qref += 0.0005;
                }
                if(joystick.getButtonState(Joystick::A_BUTTON)){
                    RevolutejointInfos[2].qref -= 0.0005;
                }


        for(auto& info : PrismaticjointInfos){
            auto joint = info.joint;
                joint->q_target() += 0.0001*pos;
                if(joint->q() > 0.8){
                    joint->q_target() = 0.8;    
                }
                if(joint->q() < 0.0){
                    joint->q_target() = 0.0;    
                }
        }   
        for(auto& info : RevolutejointInfos){
            auto joint = info.joint;
            auto q_current = joint->q();
            joint->dq_target() = info.kp*(info.qref - q_current) / dt;
            if(joint->q() + (joint->dq_target()*dt)> joint->q_upper()){
                joint->dq_target() = 0.0;    
            }
            if(joint->q() + (joint->dq_target()*dt) < joint->q_lower()){
                joint->dq_target() = 0.0;    
            }
        } 
        return true;
    }
};



CNOID_IMPLEMENT_SIMPLE_CONTROLLER_FACTORY(ExtendableArmCameraController)