/*
    \author Fumiaki Abe
*/

#include <cnoid/SimpleController>
#include <cnoid/SharedJoystick>
#include <sensor_msgs/Joy.h>
#include <boost/format.hpp>
#include <mutex>
#include <iostream>
#include <cnoid/Device>
#include <cnoid/DeviceList>
#include <cnoid/RangeSensor>
#include <cnoid/Archive>

#include <ros/ros.h>
#include <ros/node_handle.h>
#include <sensor_msgs/LaserScan.h>
#include <vector>
#include <std_msgs/String.h>


using namespace std;
using namespace cnoid;
using boost::format;


class rangesensor_publisher : public SimpleController
{
    ros::NodeHandle node1;
    ros::Subscriber node2;
    std::vector<ros::Publisher> range_sensor_publisher_;
    ros::Publisher msg_publisher_;
    std::mutex joyMutex;



    boost::shared_ptr<ros::NodeHandle> rosnode_;
    boost::shared_ptr<ros::AsyncSpinner> async_ros_spin_;
    Body* ioBody;
    BodyPtr simulationBody;
    DeviceList<RangeSensor> rangeSensors_;
    double time;
    double timestep;

public:
    virtual bool initialize(SimpleControllerIO* io) override;
    const DeviceList<RangeSensor>& rangeSensors() const {return rangeSensors_;}
    bool start();
    bool createSensor(BodyPtr body);

    virtual bool control() override;
    void updateRangeSensor(RangeSensor* sensor, ros::Publisher& publisher);



    const BodyPtr& body() const {return simulationBody;}

};


bool rangesensor_publisher::initialize(SimpleControllerIO* io)
{
    ioBody = io->body();
    simulationBody = ioBody;
    rangeSensors_ << simulationBody->devices();
    for(size_t i=0; i < rangeSensors_.size(); i++){
        RangeSensor* rangeSensor = rangeSensors_[i];
        rangeSensor->on(true);
        io->enableInput(rangeSensor);
    }

    time = 0.0;
    timestep = io->timeStep();
    return true;
}


bool rangesensor_publisher::start()
{
    std::string name = simulationBody->name();
    std::replace(name.begin(), name.end(), '-', '_');
    rosnode_ = boost::shared_ptr<ros::NodeHandle>(new ros::NodeHandle(name));
    createSensor(simulationBody);

    msg_publisher_ = rosnode_->advertise<std_msgs::String>("chatter", 10);

    async_ros_spin_.reset(new ros::AsyncSpinner(0));
    async_ros_spin_->start();

    return true;
}


bool rangesensor_publisher::createSensor(BodyPtr body)
{
    DeviceList<> devices = body->devices();
    rangeSensors_.assign(devices.extract<RangeSensor>());


    range_sensor_publisher_.resize(rangeSensors_.size());
    for(size_t i=0; i < rangeSensors_.size(); i++){
        if(RangeSensor* sensor = rangeSensors_[i]){
            std::string name = sensor->name();
            std::replace(name.begin(), name.end(), '-', '_');
            range_sensor_publisher_[i] = rosnode_->advertise<sensor_msgs::LaserScan>(name, 1);
            sensor->sigStateChanged().connect(boost::bind(&rangesensor_publisher::updateRangeSensor, 
                                              this, sensor, range_sensor_publisher_[i]));
        }
    }
}


bool rangesensor_publisher::control()
{
    std_msgs::String msg;
    msg.data = "hello world";
    ROS_INFO("publish: %s", msg.data.c_str());
    msg_publisher_.publish(msg);

    
    time += timestep;
    return true;
}



void rangesensor_publisher::updateRangeSensor(RangeSensor* sensor, ros::Publisher& publisher)
{
    sensor_msgs::LaserScan range;
    range.header.stamp.fromSec(time);
    range.header.frame_id = sensor->name();
    range.range_max = sensor->maxDistance();
    range.range_min = sensor->minDistance();
    
    if(sensor->yawRange() == 0.0){
        range.angle_max =  sensor->pitchRange() /2.0;
        range.angle_min = -sensor->pitchRange() /2.0;
        range.angle_increment = sensor->pitchStep();
    }else {
        range.angle_max =  sensor->yawRange() /2.0;
        range.angle_min = -sensor->yawRange() /2.0;
        range.angle_increment = sensor->yawStep();
    }
    range.ranges.resize(sensor->rangeData().size());
    for(size_t j=0; j < sensor->rangeData().size(); j++){
        range.ranges[j] = sensor->rangeData()[j];
    }

    publisher.publish(range);

}



CNOID_IMPLEMENT_SIMPLE_CONTROLLER_FACTORY(rangesensor_publisher)
