/**
  @file
  @author
 */

#include <cnoid/Plugin>
// #include <fmt/format.h>
#include "BodyRosItem.h"

using namespace cnoid;

namespace {

class RosBodyPlugin : public Plugin
{
public:

  RosBodyPlugin() : Plugin("RosBody")
  {
      require("Body");
  }

  virtual bool initialize() override
  {
      BodyRosItem::initialize(this);
      return true;
  }

  virtual const char* description() const override
  {
    static std::string text; // =
    //     //   fmt::format("RosBody Plugin Version {}\n", CNOID_FULL_VERSION_STRING) +
    //       "\n" +
    //       "Copyrigh (c) 2019 Japan Atomic Energy Agency.\n"
    //       "\n" +
    //       MITLicenseText();
    return text.c_str();
    //return ;
  }
};

}

CNOID_IMPLEMENT_PLUGIN_ENTRY(RosBodyPlugin)
